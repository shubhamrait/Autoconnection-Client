sudo arp-scan --retry=8 --ignoredups -I wlp9s0 --localnet
