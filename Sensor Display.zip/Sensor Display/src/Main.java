import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import javax.swing.*;    
import java.awt.event.*;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.util.concurrent.TimeUnit;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.DecimalFormat;
public class Main 
{
	static String message="00,00,00";
    static boolean running=true; 
    static String macaddr="7c:46:85:80:77:08";
    static JFrame f;
    static JProgressBar jb;
    static float A,temp=0;
    static int flag;
    public static void main(String[] args) throws Exception
    {
        Scanner sc=new Scanner(System.in);
        int i, port=6000;
        float ax,ay,az;
        String ipaddr="192.168.0.136";
        jb=new JProgressBar(0,20);
        //System.out.println("Enter port number for comunication");
        //port=sc.nextInt();
        
        /*Process p = Runtime.getRuntime().exec("sudo arp-scan --retry=8 --ignoredups -I wlan0 --localnet");
        p.waitFor();
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line = "",temp="";
        while ((line = reader.readLine()) != null) 
        {
            if(line.contains(Main.macaddr))
            {
                temp=line;
            }
        }
        String tmp=" ";
        String array[]=temp.split(Main.macaddr);
        ipaddr=array[0].trim();
        */
        
        f=new JFrame("Accelerometer sensor");//creating instance of JFrame
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel l=new JLabel();
        l.setText("Hello1");
        JLabel l1=new JLabel();
        l1.setText("Hello2");
        JLabel l2=new JLabel();
        l2.setText("Hello3");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        f.setSize(screenSize.width/2, screenSize.height/2);//400 width and 500 height  
        l.setBounds(0, 0, screenSize.width/2, screenSize.height/20);
        l1.setBounds(0, screenSize.height/20,screenSize.width/2, screenSize.height/20);
        l2.setBounds(0, screenSize.height/10,screenSize.width/2, screenSize.height/20);
        jb.setBounds(0,3*screenSize.height/20,screenSize.width/2, screenSize.height/20);
        jb.setStringPainted(true);
        f.add(jb);
        f.setLayout(null);//using no layout managers  
        f.setVisible(true);//making the frame visible 
        l.setText("123 123");
        f.add(l);
        /*f.add(l1);*/
        f.add(l2);
        l.setText("123 456");
        l1.setVisible(true);
        l1.setText("Hey there");
        f.add(l1);
        ipaddr = JOptionPane.showInputDialog(f, "Enter IP address");                     
        //ipaddr=new Scanner(System.in).nextLine();
        Thread th=new Thread(new MainThread(ipaddr,port));
        l2.setText("Client connected to "+ipaddr+" on port "+port);
        th.start();	
        (new Thread(new bar())).start();
        for(;;)
        {
        		if(Main.running==false)
                {
                    {
                    Main.running=true;
                    l1.setText("Trying to connect....");
                    th=new Thread(new MainThread(ipaddr,port));
                    th.start();
                    }
                }
        		i=0;
        		String a[]= Main.message.split(",");
        		ax=Float.parseFloat(a[0]);
        		ay=Float.parseFloat(a[1]);
        		az=Float.parseFloat(a[2]);
        		A=(float)Math.sqrt(ax*ax+ay*ay+az*az);
        		A=(float) (A-9.8);
        		jb.setValue((int)Math.abs(A));
        		if((Main.temp<Main.A)&&flag==0)
        		{
        			Main.temp=Main.A;
        		}
        	l.setText(a[0]+" "+a[1]+" "+a[2]+"   "+"A: "+A);
        }
        
    }
}
class ClientThread2
{
    static boolean running=true;
    static String message="Alright";
    static String macaddr="7c:46:85:80:77:08";
}
class MainThread implements Runnable
{
    String ipaddr;
    int port;
    public MainThread(String a,int b)
    {
        this.ipaddr=a;
        this.port=b;
    }
    public void run()
    {
        Socket sock=null;
            try 
            {
                sock = new Socket(this.ipaddr,this.port);
                Thread thread = new Thread(new SendThread(sock));
                thread.start();
                Thread thread2 =new Thread(new RecieveThread(sock));
                thread2.start();
            } 
            catch (Exception e) 
            {
            	JOptionPane.showMessageDialog(Main.f,"ERROR!!______________ main thread\n"+e.getMessage());
                Main.running=false;
                
                //System.exit(0);
            }
        
    }
}           
            /*try
            {
            sock.close();
            }
            catch(Exception xp){System.exit(0);}*/
class RecieveThread implements Runnable
{
    Socket sock=null;
    BufferedReader recieve=null;
	
    public RecieveThread(Socket sock) //constructor to initialise the values
    {
	this.sock = sock;
    }
    public void run() 
    {
        try
        {
            recieve = new BufferedReader(new InputStreamReader(this.sock.getInputStream()));//get inputstream
            String msgRecieved = "Hello";
		while(Main.running==true)
		{
                    msgRecieved = recieve.readLine();
                    if(msgRecieved.equals(null))
                    {
                        break;
                    }
                    Main.message=msgRecieved;
		}
                if(Main.running==false)
                {
                	JOptionPane.showMessageDialog(Main.f,"Exit from Receive Thread \n");
                }
        }
        catch(NullPointerException ex)
        {
        	JOptionPane.showMessageDialog(Main.f,"ERROR!!______________ receive thread\n"+ex.getMessage());
            Main.running=false;
            
        }
            catch(Exception e)
            {
            	JOptionPane.showMessageDialog(Main.f,"ERROR!!______________ receive thread\n"+e.getMessage());
            Main.running=false;
            
            //System.exit(0);
            }
	}//end run
}//end class recievethread
class SendThread implements Runnable
{
	Socket sock=null;
	PrintWriter print=null;
	BufferedReader brinput=null;
	
	public SendThread(Socket sock)
	{
		this.sock = sock;
	}//end constructor
	public void run()
        {
            try
            {
		if(sock.isConnected())
		{
                    //System.out.println("Client connected to "+sock.getInetAddress() + " on port "+sock.getPort());
                    this.print = new PrintWriter(sock.getOutputStream(), true);	
                    while(Main.running==true)
                    {
                        
			this.print.println(ClientThread2.message);
			this.print.flush();
                        
                    }//end while
		//sock.close();
                    if(Main.running==false)
                    {
                        System.out.println("Exit from Send Thread \n");
                    }
                }
            }
            catch(Exception e)
            {                
            	JOptionPane.showMessageDialog(Main.f,"ERROR!!______________ send thread\n"+e.getMessage());
                Main.running=false;
                
                //System.exit(0);
            }
	}//end run method
}//end class
class bar implements Runnable
{
	public void run()
	{
		while(true)
		{
			try
			{
			Main.flag=2;
			Main.jb.setValue((int)Math.abs(Main.A));
			Main.temp=0;
			Main.flag=0;
			Thread.sleep(3000);
			}
			catch(Exception e)
			{}
		}
	}
}