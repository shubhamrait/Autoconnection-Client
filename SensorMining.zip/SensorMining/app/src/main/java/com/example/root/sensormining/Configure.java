package com.example.root.sensormining;

public class Configure
{
    static MainActivity main;
}
