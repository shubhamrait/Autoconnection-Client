package com.example.root.sensormining;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import android.os.Handler;

import static android.hardware.Sensor.TYPE_GYROSCOPE;

public class MainActivity extends AppCompatActivity implements SensorEventListener
{
    class Accelerometer
    {
        public float ax=0;
        public float ay=0;
        public float az=0;
        Accelerometer()
        {
            this.ax=0;
            this.ay=0;
            this.az=0;
        }
    }
    public static String a="";
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Sensor mGyroscope;
    public TextView txt,txt2;
    public static final int SERVERPORT = 6000;
    private ServerSocket serverSocket;
    Accelerometer acc=new Accelerometer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=(TextView)findViewById(R.id.text1);
        txt2=(TextView)findViewById(R.id.text2);
        Configure.main=this;
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mGyroscope = mSensorManager.getDefaultSensor(TYPE_GYROSCOPE);
        ServerThread srv=new ServerThread();
        Thread t1=new Thread(srv);
        t1.start();
    }
    protected void onResume()
    {
        super.onResume();
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(this, mGyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.sensor.getName().contains("METER"))
        {
            acc.ax=event.values[0];
            acc.ay=event.values[1];
            acc.az=event.values[2];
            Configure.main.txt.setText(event.sensor.getName() + "\n" + "X: " + event.values[0] + "\n" + "Y: " + event.values[1] + "\n" + "Z: " + event.values[2] + "\n" + "R: " + Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]));
            MainActivity.a=(new Float(acc.ax)).toString()+","+(new Float(acc.ay)).toString()+","+(new Float(acc.az)).toString();
        }
        else {
            Configure.main.txt2.setText(event.sensor.getName() + "\n" + "X: " + event.values[0] + "\n" + "Y: " + event.values[1] + "\n" + "Z: " + event.values[2] + "\n" + "R: " + Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    class ServerThread implements Runnable
    {
        boolean success=true;
        CommunicationThread temp=null;
        public void run()
        {
            Socket socket = null;
            try
            {
                serverSocket = new ServerSocket(SERVERPORT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            while( (!Thread.currentThread().isInterrupted())||(status()==true))
            {

                try
                {

                    socket = serverSocket.accept();
                    socket.setSoTimeout(1000);
                    CommunicationThread commThread = new CommunicationThread(socket,this);
                    new Thread(commThread).start();
                    this.temp=commThread;

                }
                catch(SocketTimeoutException e)
                {
                    try
                    {
                        this.success = false;
                        this.wait(30);
                        socket = serverSocket.accept();
                        socket.setSoTimeout(1000);
                        CommunicationThread commThread = new CommunicationThread(socket, this);
                        new Thread(commThread).start();
                        this.temp = commThread;
                    }
                    catch (Exception exc)
                    {
                        exc.printStackTrace();
                    }

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

            }
        }
        boolean status()
        {
            if(temp.status()==false)
            {
                return(false);
            }
            return(this.success);
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private PrintWriter output;
        boolean success=true;
        ServerThread temp=null;
        public CommunicationThread(Socket clientSocket,ServerThread a)
        {
            this.temp=a;
            this.clientSocket = clientSocket;

            try {
                this.output = new PrintWriter(new OutputStreamWriter(this.clientSocket.getOutputStream()),true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run()
        {

            while((!Thread.currentThread().isInterrupted())||(status()==true) )
            {

                try {

                    this.output.println(MainActivity.a);
                    this.output.flush();


                } catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        }
        boolean status()
        {
            if(temp.status()==false)
            {
                return(false);
            }
            return(this.success);
        }


    }

}
